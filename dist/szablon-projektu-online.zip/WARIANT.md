# Wariant internetowy

Paczka jest przeznaczona do Prism, Overleaf lub podobnego edytora. Nie zawiera
lokalnego pliku `latexmkrc`. Po zaimportowaniu archiwum ustaw:

- dokument główny: `main.tex`;
- kompilator: LuaLaTeX.

Plików pomocniczych i PDF nie należy dodawać ręcznie do paczki źródłowej.
