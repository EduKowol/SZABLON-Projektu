# Szablon dokumentacji projektu (LaTeX)

Szablon służy do przygotowania raportu z projektu realizowanego w ramach zajęć. Obsługuje projekty indywidualne i zespołowe.

## Powiązany szablon pracy dyplomowej

Szablon dokumentacji projektu wykorzystuje konwencje opracowane dla
[szablonu pracy dyplomowej](https://github.com/EduKowol/SZABLON-Pracy-Dyplomowej),
ale ma uproszczoną strukturę dostosowaną do projektów realizowanych w ramach
zajęć. Przy przygotowywaniu pracy inżynierskiej, magisterskiej lub doktorskiej
należy skorzystać z repozytorium
[EduKowol/SZABLON-Pracy-Dyplomowej](https://github.com/EduKowol/SZABLON-Pracy-Dyplomowej).

## Szybki start

1. Uzupełnij `config/metadata.tex`, zwłaszcza tytuł, przedmiot, prowadzącego i autorów.
2. Zastąp teksty instruktażowe w `chapters/` własną treścią.
3. Dodaj źródła do `bibliografia.bib` i cytuj je przez `\cite{klucz}`.
4. Uruchom `latexmk main.tex`.

Gotowy dokument powstanie jako `build/main.pdf`.

## Autorzy projektu

Autorów wpisuje się w `\projectauthors`. Każdy wiersz zawiera imię i nazwisko oraz numer albumu:

```tex
\newcommand{\projectauthors}{%
  Anna Nowak & 123456 \\
  Jan Kowalski & 234567 \\
}
\newcommand{\projectpdfauthors}{Anna Nowak, Jan Kowalski}
```

## Tryb roboczy i końcowy

Podczas pracy pozostaw `\projectstatus` ustawiony na `draft`. Przed oddaniem zmień wartość na `final`; brak podstawowych metadanych spowoduje wtedy błąd kompilacji.

## Struktura raportu

- wprowadzenie;
- cel, zakres i wymagania;
- koncepcja i projekt rozwiązania;
- realizacja;
- weryfikacja i wyniki;
- organizacja i przebieg projektu;
- podsumowanie i wnioski;
- oświadczenie o wykorzystaniu narzędzi AI;
- podział zadań i procentowy udział autorów;
- bibliografia i opcjonalne załączniki.

Układ jest propozycją. Rozdziały można łączyć, skracać lub usuwać zgodnie z wymaganiami prowadzącego i charakterem projektu.

Oświadczenie o wykorzystaniu AI oraz tabela wkładu autorów są domyślnie
włączone. Ich treść znajduje się w `backmatter/`, a widoczność kontrolują
ustawienia `\showaideclaration` i `\showcontributions` w
`config/metadata.tex`.

## Rysunki, jednostki i kod

Rysunki wstawiaj przez `\projectgraphic`, jednostki zapisuj pakietem `siunitx`, np. `\qty{12}{\volt}`, a kod przechowuj poza plikiem rozdziału i wczytuj przez `\lstinputlisting`.

## Kompilacja

```text
latexmk main.tex
latexmk -g main.tex   # pełne przeliczenie po usunięciu błędu
latexmk -C main.tex   # usunięcie artefaktów kompilacji
```

## Gotowe paczki ZIP

Katalog `dist/` zawiera dwie przenośne wersje szablonu:

- `szablon-projektu-local.zip` — do pracy na komputerze; zawiera `latexmkrc`;
- `szablon-projektu-online.zip` — do Prism, Overleaf lub podobnego edytora;
  nie zawiera lokalnej konfiguracji LatexMk.

Oba archiwa zawierają źródła, instrukcje, rozdziały, oświadczenia końcowe,
przykładową bibliografię i generator paczek. Nie zawierają plików z `build/`,
`tmp/`, wcześniejszych archiwów ani innych artefaktów kompilacji.

Paczki tworzy program `tools/create_release.py`:

```text
python tools/create_release.py --target local
python tools/create_release.py --target online
```

Bez opcji `--target` program interaktywnie zapyta o wariant. Własną nazwę pliku
można podać przez `--output ścieżka/do/pliku.zip`.

Po każdej zmianie plików wchodzących w skład szablonu należy ponownie
wygenerować oba archiwa i zapisać je w repozytorium. Katalog `dist/` nie jest
wykluczony przez `.gitignore`.
