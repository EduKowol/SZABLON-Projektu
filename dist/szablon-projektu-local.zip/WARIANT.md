# Wariant lokalny

Paczka zawiera `latexmkrc` i jest przeznaczona do kompilacji na komputerze.

W systemie Windows zainstaluj MiKTeX oraz interpreter Perl (np. Strawberry
Perl), ponieważ `latexmk` jest skryptem napisanym w Perlu. Po instalacji zamknij
i ponownie otwórz terminal oraz edytor LaTeX, a następnie sprawdź środowisko:

```text
perl --version
latexmk -v
lualatex --version
biber --version
```

Jeżeli polecenie `perl` nie jest rozpoznawane, nie rozpoczynaj diagnozowania
szablonu — najpierw zainstaluj Perl i uruchom terminal ponownie.

W katalogu projektu uruchom:

```text
latexmk main.tex
```

LuaLaTeX i katalog wynikowy `build/` zostaną wybrane automatycznie.
Gotowy dokument powstanie jako `build/main.pdf`.
