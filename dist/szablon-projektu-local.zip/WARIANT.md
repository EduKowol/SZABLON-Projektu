# Wariant lokalny

Paczka zawiera `latexmkrc`. W katalogu projektu uruchom:

```text
latexmk main.tex
```

LuaLaTeX i katalog wynikowy `build/` zostaną wybrane automatycznie.
Gotowy dokument powstanie jako `build/main.pdf`.
